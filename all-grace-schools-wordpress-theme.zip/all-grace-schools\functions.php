<?php
/**
 * All Grace Schools WordPress Theme
 * Developed by Marvglobal Digitalz
 * Website: https://marvs-digital-showcase.vercel.app/
 */

if (!defined('ABSPATH')) {
    exit;
}

function ags_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
}
add_action('after_setup_theme', 'ags_theme_setup');

function ags_enqueue_assets() {
    wp_enqueue_style(
        'ags-google-fonts',
        'https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Hanken+Grotesk:wght@400;500;600;700&family=Outfit:wght@400;500;600;700&display=swap',
        array(),
        null
    );

    wp_enqueue_style(
        'ags-theme-style',
        get_stylesheet_uri(),
        array(),
        '1.1.0'
    );
}
add_action('wp_enqueue_scripts', 'ags_enqueue_assets');

// Custom routing for all pages and legacy redirects
function ags_custom_routing() {
    if (is_admin() || (defined('DOING_CRON') && DOING_CRON) || (defined('REST_REQUEST') && REST_REQUEST)) {
        return;
    }

    $uri = $_SERVER['REQUEST_URI'] ?? '';

    // If index.html is directly requested, 301 redirect to actual root URL
    if (strpos($uri, 'index.html') !== false) {
        wp_safe_redirect(home_url('/'), 301);
        exit;
    }

    $raw_path = parse_url($uri, PHP_URL_PATH);
    $path = trim($raw_path, '/');

    // Strip WordPress subdirectory if installed in a subfolder
    $site_path = trim(parse_url(home_url(), PHP_URL_PATH) ?? '', '/');
    if ($site_path && strpos($path, $site_path) === 0) {
        $path = trim(substr($path, strlen($site_path)), '/');
    }

    // Legacy 301 redirects
    $legacy_redirects = array(
        'about' => '/about-our-school',
        'admissions' => '/admission-process',
        'contact' => '/contacts',
        'events' => '/school-life',
        'media' => '/school-life',
        'news-list-vc' => '/news',
    );
    if (isset($legacy_redirects[$path])) {
        wp_safe_redirect(home_url($legacy_redirects[$path]), 301);
        exit;
    }

    // Custom route templates map
    $routes_map = array(
        '' => 'front-page.php',
        'about-our-school' => 'page-about-our-school.php',
        'academics' => 'page-academics.php',
        'admission-process' => 'page-admission-process.php',
        'school-life' => 'page-school-life.php',
        'news' => 'page-news.php',
        'contacts' => 'page-contacts.php',
        'how-to-enroll-your-child-in-a-class' => 'page-how-to-enroll-your-child-in-a-class.php',
        'meet-our-proprietor' => 'page-meet-our-proprietor.php',
        'why-you-should-choose-all-grace-schools' => 'page-why-you-should-choose-all-grace-schools.php',
        'school-cms' => 'admin.html',
        'cms' => 'admin.html',
        'admin.html' => 'admin.html',
    );

    if (isset($routes_map[$path])) {
        status_header(200);
        $file = get_template_directory() . '/' . $routes_map[$path];
        if (file_exists($file)) {
            include $file;
            exit;
        }
    }
}
add_action('template_redirect', 'ags_custom_routing', 1);
