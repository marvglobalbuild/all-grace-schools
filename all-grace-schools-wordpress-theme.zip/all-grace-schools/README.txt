# How to Install this Theme in WordPress

1. Log in to your **WordPress Admin Dashboard** (`https://yourdomain.com/wp-admin`).
2. In the left menu, go to **Appearance** → **Themes**.
3. Click the **Add New Theme** button at the top, then click **Upload Theme**.
4. Click **Choose File** and select `all-grace-schools-wordpress-theme.zip`.
5. Click **Install Now**.
6. Once uploaded, click **Activate**.
7. Visit your website homepage — All Grace Schools is now live on your WordPress site!

---

### Managing School Content & Admissions
- You can access the **School CMS** anytime at:
  `https://yourdomain.com/school-cms` or `https://yourdomain.com/admin.html` (or via the link in the footer).
- Enter the confidential administrative secret passkey to unlock your dashboard.

Theme developed by **Marvglobal Digitalz** (https://marvs-digital-showcase.vercel.app/).
