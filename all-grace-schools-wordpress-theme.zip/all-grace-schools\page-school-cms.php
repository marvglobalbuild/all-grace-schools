<?php
/**
 * Template Name: School CMS
 */
include get_template_directory() . '/admin.html';
exit;
