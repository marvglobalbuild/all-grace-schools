<?php
/**
 * All Grace Schools WordPress Theme
 * Developed by Marvglobal Digitalz
 * Website: https://marvs-digital-showcase.vercel.app/
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

function ags_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
}
add_action('after_setup_theme', 'ags_theme_setup');

function ags_enqueue_assets() {
    // Google Fonts
    wp_enqueue_style(
        'ags-google-fonts',
        'https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Hanken+Grotesk:wght@400;500;600;700&family=Outfit:wght@400;500;600;700&display=swap',
        array(),
        null
    );

    // Main Theme Stylesheet
    wp_enqueue_style(
        'ags-theme-style',
        get_stylesheet_uri(),
        array(),
        '1.0.0'
    );
}
add_action('wp_enqueue_scripts', 'ags_enqueue_assets');
