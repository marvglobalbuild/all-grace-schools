========================================================================
ALL GRACE SCHOOLS — OFFICIAL WORDPRESS THEME
Developed by Marvglobal Digitalz
========================================================================

HOW TO INSTALL THIS THEME ON WORDPRESS:

METHOD 1: WORDPRESS ADMIN DASHBOARD (EASIEST & RECOMMENDED)
------------------------------------------------------------------------
1. Use the file: 'all-grace-schools-wordpress-theme-LIGHT.zip' (~4.2MB).
2. Go to your WordPress Admin dashboard:
   Appearance > Themes > Add New > Upload Theme.
3. Choose 'all-grace-schools-wordpress-theme-LIGHT.zip' and click 'Install Now'.
4. Click 'Activate'.
5. Done! All pages, styles, layout, and photos will be active instantly.

* Why the LIGHT version?
Most shared WordPress hosts have a file upload limit of 2MB to 10MB.
The full package is 22MB because of the 17.5MB raw campus video tour file,
which causes WordPress to show "The link you followed has expired."
The LIGHT version is only ~4MB so it installs effortlessly!

To enable the video tour:
- You can upload 'school-video.mp4' directly into your WordPress Media Library, or
- Upload 'school-video.mp4' via cPanel File Manager to:
  wp-content/themes/all-grace-schools/media/school-video.mp4


METHOD 2: CPANEL FILE MANAGER (INSTALL FULL 22MB BUNDLE DIRECTLY)
------------------------------------------------------------------------
If you want the complete bundle with the 17.5MB video pre-packaged:
1. Log into your hosting cPanel.
2. Open 'File Manager'.
3. Navigate to: public_html/wp-content/themes/
4. Click 'Upload' and select 'all-grace-schools-wordpress-theme.zip'.
5. Once uploaded, right-click the zip file in cPanel and select 'Extract'.
6. Delete the uploaded .zip file (optional).
7. Go to WordPress Admin > Appearance > Themes.
8. You will see 'All Grace Schools' — click 'Activate'!


ACCESSING THE BUILT-IN CMS:
------------------------------------------------------------------------
Visit: https://yourdomain.com/school-cms
(or https://yourdomain.com/cms)
This gives you the school management dashboard to update notices,
contacts, fees, and gallery images.
========================================================================
